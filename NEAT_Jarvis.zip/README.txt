#insall NEAT-Python library

pip install neat-python

#run the training program
python jarvis.py